package controller;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DAO;
import model.JavaBeans;
import model.JavaBeans2;
import model.JavaBeans3;

import java.util.Date;

@WebServlet(urlPatterns = { "/controller", "/verifique","/main","/votarCand","/main2", "/selectEdit", "/inserir","/inserir2","/resultCand", "/select", "/update",
		"/updateCand", "/login", "/delete","/delete2", "/inserircand","/mainCandView"})
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DAO dao = new DAO();
	JavaBeans usuarioX = new JavaBeans();
	JavaBeans2 candidatoX = new JavaBeans2();
	JavaBeans3 voto=new JavaBeans3();
	 
	public Controller() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		dao.testeConexao();
		String action = request.getServletPath();
		System.out.println(action);

		if (action.equals("/main")) {
			user(request, response);
		} else if (action.equals("/main2")) {
			/* candidato */
			allCandidatos(request, response);

		}else if (action.equals("/mainCandView")) {
			/* candidato */
				allCandidatos(request, response);
			 
		}else if (action.equals("/votarCand")) {
			/* candidato */
			votacao(request, response);
		 
	}
		else if (action.equals("/resultCand")) {
			/* candidato */
			allCandidatos(request, response);
		 
	} else if (action.equals("/inserir")) {
			inserirUsuario(request, response);

		}  else if (action.equals("/inserir2")) {
			inserirUsuario(request, response);

		}else if (action.equals("/select")) {
			listarUsuario(request, response);

		} else if (action.equals("/update")) {
			editarUsuario(request, response);

		} else if (action.equals("/login")) {
			logar(request, response);

		}else if (action.equals("/verifique")) {
            verificacaoUsuario(request, response);
        } else if (action.equals("/delete")) {
			removerUsuario(request, response);

		} else if (action.equals("/delete2")) {
			removerCandidato(request, response);

		} else if (action.equals("/inserircand")) {
			/* candidato */
			novoCandidato(request, response);

		} else if (action.equals("/selectEdit")) {
			/* candidato */
			listarCandidato(request, response);

		} else if (action.equals("/updateCand")) {
			/* candidato */
			editarCandidato(request, response);

		} else {
			response.sendRedirect("cadastro.html");
		}
	}

	

	private void votacao(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    /// Verifiar a autenticação do usuário
	    JavaBeans usuario = (JavaBeans) request.getSession().getAttribute("usuario");
	    if (usuario == null) {
	        response.sendRedirect("login.jsp"); 
	        return;
	    }

	    String idCandidato = request.getParameter("idCandidato");
	    String usuarioNome = usuario.getUsuario();

	    DAO dao = new DAO();

	    if (dao.verificarVoto(usuarioNome, idCandidato) || dao.verificarVot1(usuarioNome)) {
	        response.sendRedirect("jaVotou.jsp");
	        return;
	    }
	   

	    int numeroDeVotos = dao.obterNumeroDeVotosDoCandidato(idCandidato);
	    dao.atualizarNumeroDeVotos(idCandidato, numeroDeVotos + 1);

	    
	    JavaBeans3 voto = new JavaBeans3();
	    voto.setUsuario(usuarioNome);
	    voto.setIdCandidato((idCandidato));
	    voto.setDatta(new Date()); 

	   
	    dao.inserirVoto(voto);

	    JavaBeans2 candidato = dao.obterCandidatoPorId(idCandidato);

	    request.setAttribute("usuario", usuario); 
	    request.setAttribute("candidato", candidato); 
	    request.setAttribute("voto", voto);

	    
	    request.setAttribute("voto",voto);
	    request.getRequestDispatcher("VerificacaoAdm.jsp").forward(request, response);
	}


	private void listarCandidato(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String idUsuario = request.getParameter("idUsuario");
		// System.out.println(idUsuario);
		candidatoX.setIdUsuario(idUsuario);
		dao.selecionarCandidato(candidatoX);
		request.setAttribute("idUsuario", candidatoX.getIdUsuario());
		request.setAttribute("usuario", candidatoX.getUsuario());
		request.setAttribute("email", candidatoX.getEmail());
		request.setAttribute("faculty", candidatoX.getFaculty());
		request.setAttribute("course", candidatoX.getCourse());
		request.setAttribute("ano", candidatoX.getAno());
		request.setAttribute("votos", candidatoX.getVotos());
		request.setAttribute("proposta", candidatoX.getProposta());
		
		RequestDispatcher rd = request.getRequestDispatcher("EditarCandidatoAdm.jsp");
		rd.forward(request, response);
	}

	// lISTAR CONTACTO
	private void allCandidatos(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String action = request.getServletPath();
		
		ArrayList<JavaBeans2> listar = dao.listarCandidatos();
		request.setAttribute("allcandidatos", listar);
		if (action.equals("/main2"))
				{
			RequestDispatcher rd = request.getRequestDispatcher("votCand.jsp");
			rd.forward(request, response);
		
				
				}else if(action.equals("/mainCandView")){
					RequestDispatcher rd = request.getRequestDispatcher("votCandidatoUsuario.jsp");
					rd.forward(request, response);
				}
		else {
			RequestDispatcher rd = request.getRequestDispatcher("Resultados.jsp");
			rd.forward(request, response);
				}

	}

	// insercao de novoCandidato
	private void novoCandidato(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		candidatoX.setIdUsuario(request.getParameter("idUsuario"));
		candidatoX.setUsuario(request.getParameter("usuario"));
		candidatoX.setEmail(request.getParameter("email"));
		candidatoX.setFaculty(request.getParameter("faculty"));
		candidatoX.setCourse(request.getParameter("course"));
		candidatoX.setAno(request.getParameter("ano"));
		// Converter o valor da string para um inteiro
	   /* String votosStr = request.getParameter("votos");
	    int votos = 0;  // Defina um valor padrão se não puder converter
	    try {
	        votos = Integer.parseInt(votosStr);
	    } catch (NumberFormatException e) {
	        // Lidar com erro de conversão (por exemplo, definir um valor padrão)
	    }*/
	    candidatoX.setVotos(0);
	    candidatoX.setProposta(request.getParameter("proposta"));;
		dao.inserirCandidato(candidatoX);
		response.sendRedirect("main2");

	}

	// Ediar candidato
	private void editarCandidato(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		candidatoX.setProposta(request.getParameter("proposta"));;
		dao.alterarCandidato(candidatoX);
		response.sendRedirect("main2");
		
	}
	private void removerCandidato(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String idUsuario = request.getParameter("idUsuario");
		// System.out.println(idUsuario);
		// setar
		candidatoX.setIdUsuario(idUsuario);
		dao.deletarCandidato(candidatoX);
		// redirecionar para o documento votCand.jsp (actualizndo alteracoes)
		response.sendRedirect("main2");

	}
	
	

//-----------------------------Usuarios--->Nao Modificar Nada por enquanto----------------------------------------------------------------
//listar usuario
	private void user(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		//String action = request.getServletPath();
		ArrayList<JavaBeans> lista = dao.listarUsuario();
		// Encaminhar a lista ao documento cadastro.jsp
		request.setAttribute("user", lista);
		
			RequestDispatcher rd = request.getRequestDispatcher("cadastro.jsp");
			rd.forward(request, response);
	

	}

	private void inserirUsuario(HttpServletRequest request, HttpServletResponse response) throws IOException {
	
		String action = request.getServletPath();

		// sETAR AS vARIVEIS
		usuarioX.setUsuario(request.getParameter("usuario"));
		usuarioX.setEmail(request.getParameter("email"));
		usuarioX.setPassword(request.getParameter("password"));
		usuarioX.setFaculty(request.getParameter("faculty"));
		usuarioX.setCourse(request.getParameter("course"));
		usuarioX.setAno(request.getParameter("ano"));

		// Invocar o metodo INSERIR ,PASSANDO O OBJECTO PARA BD

		dao.inserirUsuario(usuarioX);
		
		if (action.equals("/inserir"))
		{
		response.sendRedirect("main");
		}
		else {
			response.sendRedirect("index.html");
		}
	}

	// Editar ou capturar o usuario atraves de id no controleer(update parte 1)
	private void listarUsuario(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String idUsuario = request.getParameter("idUsuario");
		System.out.println(idUsuario);
		// Setar a variavel JavaBeans
		usuarioX.setIdUsuario(idUsuario);
		// executar o metodo selecionar USUARIO da classe DAO

		dao.selecionarUsuario(usuarioX);

		// SETAR OS ATRBUTOS DO cadastro com conteudo de javaBeans
		request.setAttribute("idUsuario", usuarioX.getIdUsuario());
		request.setAttribute("usuario", usuarioX.getUsuario());
		request.setAttribute("email", usuarioX.getEmail());
		request.setAttribute("password", usuarioX.getPassword());
		request.setAttribute("faculty", usuarioX.getFaculty());
		request.setAttribute("course", usuarioX.getCourse());
		request.setAttribute("ano", usuarioX.getAno());
		// Encaminhar ao documento editar.jsp
		RequestDispatcher rd = request.getRequestDispatcher("Editar.jsp");
		rd.forward(request, response);
	}

//UPdate no controller parte2
	private void editarUsuario(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// setar variaveis
		usuarioX.setIdUsuario(request.getParameter("idUsuario"));
		usuarioX.setUsuario(request.getParameter("usuario"));
		usuarioX.setEmail(request.getParameter("email"));
		usuarioX.setPassword(request.getParameter("password"));
		usuarioX.setFaculty(request.getParameter("faculty"));
		usuarioX.setCourse(request.getParameter("course"));
		usuarioX.setAno(request.getParameter("ano"));
		dao.alterarUsuario(usuarioX);
		// REDIRECIONAR PARA o documetno cadastro.jsp (actualizando as alteracoes)
		response.sendRedirect("main");

	}

	private void removerUsuario(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String idUsuario = request.getParameter("idUsuario");
		// System.out.println(idUsuario);
		// setar
		usuarioX.setIdUsuario(idUsuario);
		dao.deletarUsuario(usuarioX);
		// redirecionar para o documento cadastro.jsp (actualizndo alteracoes)
		response.sendRedirect("main");

	}

	private void logar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String email = request.getParameter("email");
	    String password = request.getParameter("password");

	    if (email.equals("dhulkiflyamisse@gmail.com") && password.equals("dhulki")) {
	        // Autenticação bem-sucedida para o administrador
	        response.sendRedirect("main");
	    } else {
	        DAO dao = new DAO(); // Crie uma instância da classe DAO

	        JavaBeans usuario = dao.autenticarUsuario(email, password);

	        if (usuario != null) {
	            request.getSession().setAttribute("usuario", usuario);
	            response.sendRedirect("VerificacaoUsuario.jsp");
	        } else {
	            // Autenticação falhou, você pode redirecionar para uma página de erro ou lidar de acordo com a necessidade
	             System.out.println("Email ou senha incorreta ou usuário não existe no banco de dados");
	             request.setAttribute("loginError", "Email ou senha incorreta ");
	             RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
	             rd.forward(request, response);
	        }
	    }
	}


	
	private void verificacaoUsuario(HttpServletRequest request, HttpServletResponse response)
	        throws IOException, ServletException {
	    // Obtenha os valores dos campos do usuário a partir do request
	    String usuario = request.getParameter("usuario");
	    String email = request.getParameter("email");
	    String password = request.getParameter("password");
	    String faculty = request.getParameter("faculty");
	    String course = request.getParameter("course");
	    String ano = request.getParameter("ano");

	   
	    usuarioX.setUsuario(usuario);
	    usuarioX.setEmail(email);
	    usuarioX.setPassword(password);
	    usuarioX.setFaculty(faculty);
	    usuarioX.setCourse(course);
	    usuarioX.setAno(ano);

	   
	    request.setAttribute("usuario", usuarioX);
	  
	    RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
	    rd.forward(request, response);
	}


}
