package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

public class DAO {

	/** Modulo de Conexão **/
	// PARAMETROS DE CONEXAO

	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/evoto?useTimezone=true&serverTimezone=UTC";
	private String user = "root";
	private String password = "123456";

	private Connection conectar() {
		Connection con = null;

		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			// System.out.println("Conectado");
			return con;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}

	public void testeConexao() {
		try {
			Connection con = conectar();
			System.out.println(con);
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	// CRUD ==CREate para Candidato
	public void inserirCandidato(JavaBeans2 candidatoX) {
	    String inserirX = "INSERT INTO candidatos(idUsuario, usuario, email, faculty, course, ano,proposta,votos) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
	    try {
	        Connection con = conectar();
	        PreparedStatement pst = con.prepareStatement(inserirX);

	        pst.setString(1, candidatoX.getIdUsuario());
	        pst.setString(2, candidatoX.getUsuario());
	        pst.setString(3, candidatoX.getEmail());
	        pst.setString(4, candidatoX.getFaculty());
	        pst.setString(5, candidatoX.getCourse());
	        pst.setString(6, candidatoX.getAno());
	        pst.setString(7, candidatoX.getProposta());
	        pst.setInt(8, candidatoX.getVotos());
	       
	   

	        pst.executeUpdate();
	        con.close();
	    } catch (Exception e) {
	        System.out.println(e);
	    }
	}


	// crud == read candidato
	public ArrayList<JavaBeans2> listarCandidatos() {
		ArrayList<JavaBeans2> allcandidatos = new ArrayList<>();
		String readC = "select * from candidatos order by usuario";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(readC);
			ResultSet rs = pst.executeQuery();
			// enquanto houer candidatos sera executado
			while (rs.next()) {
				String idCandidato = rs.getString(1);
				String idUsuario = rs.getString(2);
				String usuario = rs.getString(3);
				String email = rs.getString(4);
				String faculty= rs.getString(5);
				String course = rs.getString(6);
				String ano= rs.getString(7);
				String proposta = rs.getString(8);
				int votos =rs.getInt(9);
				allcandidatos.add(new JavaBeans2(idCandidato, idUsuario, usuario, email,faculty,course,ano, proposta,votos));
			}

			con.close();

			return allcandidatos;
		} catch (Exception e) {

			System.out.println(e);
			return null;
		}

	}

	// CRUD __update p1
	public void selecionarCandidato(JavaBeans2 candidatoX) {

		String readCand = "select * from candidatos where idUsuario=?";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(readCand);
			pst.setString(1, candidatoX.getIdUsuario());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				// Setar as Variaveis JavaBeans2
				candidatoX.setIdCandidato(rs.getString(1));
				candidatoX.setIdUsuario(rs.getString(2));
				candidatoX.setUsuario(rs.getString(3));
				 candidatoX.setEmail(rs.getString(4));
			        candidatoX.setFaculty(rs.getString(5));
			        candidatoX.setCourse(rs.getString(6));
			        candidatoX.setAno(rs.getString(7));
			       
			        candidatoX.setProposta(rs.getString(8));
			        candidatoX.setVotos(rs.getInt(9));
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void alterarCandidato(JavaBeans2 candidatoX) {
	    String updateQuery = "UPDATE candidatos SET usuario=?, email=?,faculty=?,course=?, ano=?,votos=?, proposta=? WHERE idUsuario=?";
	    try {
	        Connection con = conectar();
	        PreparedStatement pst = con.prepareStatement(updateQuery);

	        pst.setString(1, candidatoX.getUsuario());
	        pst.setString(2, candidatoX.getEmail());
	        pst.setString(3, candidatoX.getFaculty());
	        pst.setString(4, candidatoX.getCourse());
	        pst.setString(5, candidatoX.getAno());
	        pst.setInt(6, candidatoX.getVotos());
	        pst.setString(7, candidatoX.getProposta());
	        pst.setString(8, candidatoX.getIdUsuario());

	        pst.executeUpdate();
	        con.close();
	    } catch (Exception e) {
	        System.out.println(e);
	    }
	}

	
	public void deletarCandidato(JavaBeans2 candidatoX) {

		String delete = "delete from candidatos where idUsuario=?";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(delete);
			pst.setString(1, candidatoX.getIdUsuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	
	public int obterNumeroDeVotosDoCandidato(String idCandidato) {
        int numeroDeVotos = 0;
        String sql = "SELECT votos FROM candidatos WHERE idCandidato = ?";
        
        Connection con = conectar();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, idCandidato);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    numeroDeVotos = rs.getInt("votos");
                }
            }
        } catch (Exception e) {
            System.out.println(3);
        }

        return numeroDeVotos;
    }

    public void atualizarNumeroDeVotos(String idCandidato, int novoNumeroDeVotos) {
        String sql = "UPDATE candidatos SET votos = ? WHERE idCandidato= ?";
        Connection con = conectar();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, novoNumeroDeVotos);
            pst.setString(2, idCandidato);
            pst.executeUpdate();
        } catch (Exception e) {
           System.out.println(e);
        }
    }

	//////////////////////////////////////////////////////////////////////////////////////////////////
	// CRUD ==CREATE
	public void inserirUsuario(JavaBeans usuarioX) {
		String inserir = "INSERT INTO USUARIO (usuario, email, password, faculty, course, ano) VALUES (?, ?, ?, ?, ?, ?)";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(inserir);
			pst.setString(1, usuarioX.getUsuario());
			pst.setString(2, usuarioX.getEmail());
			pst.setString(3, usuarioX.getPassword());
			pst.setString(4, usuarioX.getFaculty());
			pst.setString(5, usuarioX.getCourse());
			pst.setString(6, usuarioX.getAno());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// CRUD ==READ
	public ArrayList<JavaBeans> listarUsuario() {
		ArrayList<JavaBeans> user = new ArrayList<>();
		String read = "select * from usuario order by usuario";

		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(read);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				String idUsuario = rs.getString(1);
				String usuario = rs.getString(2);
				String email = rs.getString(3);
				String password = rs.getString(4);
				String faculty = rs.getString(5);
				String course = rs.getString(6);
				String ano = rs.getString(7);

				user.add(new JavaBeans(idUsuario, usuario, email, password, faculty, course, ano));
			}

			con.close();

			return user; 

		} catch (Exception e) {
			System.out.println(e);
			return null; 
		}
	}

	// CRUD ==UPDATE
	// SELECIONAR O USUARIO ,selct usuario parte 1 do DAO
	public void selecionarUsuario(JavaBeans usuarioX) {

		String read2 = "select * from usuario where idUsuario=?";

		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(read2);
			pst.setString(1, usuarioX.getIdUsuario());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				// Setar as Variaveis JavaBeans
				usuarioX.setIdUsuario(rs.getString(1));
				usuarioX.setUsuario(rs.getString(2));
				usuarioX.setEmail(rs.getString(3));
				usuarioX.setPassword(rs.getString(4));
				usuarioX.setFaculty(rs.getString(5));
				usuarioX.setCourse(rs.getString(6));
				usuarioX.setAno(rs.getString(7));

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	// update parte 2 do DAO

	public void alterarUsuario(JavaBeans usuarioX) {
		String actualizar = "update usuario set usuario=?,email=?,password=?,faculty=?,course=?,ano=? where idUsuario=?";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(actualizar);
			pst.setString(1, usuarioX.getUsuario());
			pst.setString(2, usuarioX.getEmail());
			pst.setString(3, usuarioX.getPassword());
			pst.setString(4, usuarioX.getFaculty());
			pst.setString(5, usuarioX.getCourse());
			pst.setString(6, usuarioX.getAno());
			pst.setString(7, usuarioX.getIdUsuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public JavaBeans autenticarUsuario(String email, String password) {
	    JavaBeans usuario = null;
	    String query = "SELECT usuario,email, course, ano FROM usuario WHERE email = ? AND password = ?";

	    try {
	        Connection con = conectar();
	        PreparedStatement pst = con.prepareStatement(query);
	        pst.setString(1, email);
	        pst.setString(2, password);
	        ResultSet rs = pst.executeQuery();

	        if (rs.next()) {
	            // EncontrAR uma correspondência no banco de dados
	            usuario = new JavaBeans();
	            usuario.setUsuario(rs.getString("usuario"));
	            usuario.setEmail(rs.getString("email"));
	            usuario.setCourse(rs.getString("course"));
	            usuario.setAno(rs.getString("ano"));
	           
	        }

	        con.close();
	    } catch (Exception e) {
	        System.out.println(e);
	    }
	    return usuario;
	}




	// CRUD==DELETE
	public void deletarUsuario(JavaBeans usuarioX) {
		String delete = "delete from usuario where idUsuario=?";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(delete);
			pst.setString(1, usuarioX.getIdUsuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	/////////////////////////////////////VOTOS MANIPULACAO////////////////////////////////////////////////////////////////
	
	 public boolean verificarVoto(String usuarioNome, String idCandidato) {
	        String sql = "SELECT COUNT(*) FROM Votar WHERE usuario = ? AND idCandidato = ?";

	        try (Connection con = conectar();
	             PreparedStatement pst = con.prepareStatement(sql)) {
	            pst.setString(1, usuarioNome);
	            pst.setString(2, idCandidato);
	            ResultSet rs = pst.executeQuery();

	            if (rs.next()) {
	                int count = rs.getInt(1);
	                return count > 0;
	            }
	        } catch (Exception e) {
	            System.out.println(e);
	        }

	        return false;
	    }
	 
	 public boolean verificarVot1(String usuarioNome) {
	        String sql = "SELECT COUNT(*) FROM Votar WHERE usuario = ?";

	        try (Connection con = conectar();
	             PreparedStatement pst = con.prepareStatement(sql)) {
	            pst.setString(1, usuarioNome);
	       
	            ResultSet rs = pst.executeQuery();

	            if (rs.next()) {
	                int count = rs.getInt(1);
	                return count > 0;
	            }
	        } catch (Exception e) {
	            System.out.println(e);
	        }

	        return false;
	    }
	 

	 public void registrarVoto(String usuarioNome, String idCandidato) {
	        String sql = "INSERT INTO Votar (usuario, idCandidato, datta) VALUES (?, ?, NOW())";

	        try (Connection con = conectar();
	             PreparedStatement pst = con.prepareStatement(sql)) {
	            pst.setString(1, usuarioNome);
	            pst.setString(2, idCandidato);
	            pst.executeUpdate();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	    }



	    public JavaBeans3 obterInformacoesVoto(String usuarioNome, String idCandidato) {
	        String sql = "SELECT * FROM Votar WHERE usuario = ? AND idCandidato = ?";
	        JavaBeans3 voto = new JavaBeans3();

	        try (Connection con = conectar();
	             PreparedStatement pst = con.prepareStatement(sql)) {
	            pst.setString(1, usuarioNome);
	            pst.setString(2, idCandidato);
	            ResultSet rs = pst.executeQuery();

	            if (rs.next()) {
	                voto.setIdVoto(rs.getString("idVoto"));
	                voto.setUsuario(rs.getString("usuario"));
	                voto.setIdCandidato(rs.getString("idCandidato"));
	                Timestamp timestamp = rs.getTimestamp("datta");
	                if (timestamp != null) {
	                    voto.setDatta(new Date(timestamp.getTime()));
	                }
	            }
	        } catch (Exception e) {
	            System.out.println(e);
	        }

	        return voto;
	    }
	    
	    
	    public JavaBeans2 obterCandidatoPorId(String idCandidato) {
	        Connection con = conectar();
	        String sql = "SELECT * FROM candidatos WHERE IdCandidato = ?";
	        JavaBeans2 candidato = new JavaBeans2();

	        try (PreparedStatement pst = con.prepareStatement(sql)) {
	            pst.setString(1, idCandidato);
	            ResultSet rs = pst.executeQuery();

	            if (rs.next()) {
	                candidato.setIdCandidato(rs.getString("IdCandidato"));
	                candidato.setIdUsuario(rs.getString("idUsuario"));
	                candidato.setUsuario(rs.getString("usuario"));
	                candidato.setEmail(rs.getString("email"));
	                candidato.setFaculty(rs.getString("faculty"));
	                candidato.setCourse(rs.getString("course"));
	                candidato.setAno(rs.getString("ano"));
	                candidato.setProposta(rs.getString("proposta"));
	                candidato.setVotos(rs.getInt("votos"));
	            }
	        } catch (Exception e) {
	           System.out.println(e);
	        }

	        return candidato;
	    }

	
	    
	    public void inserirVoto(JavaBeans3 voto) {
	        String inserir = "INSERT INTO Votar (usuario, idCandidato, datta) VALUES (?, ?, ?)";
	        try {
	            Connection con = conectar();
	            PreparedStatement pst = con.prepareStatement(inserir);
	            pst.setString(1, voto.getUsuario());
	            pst.setString(2, voto.getIdCandidato());
	            pst.setTimestamp(3, new Timestamp(voto.getDatta().getTime())); // Use a data do voto

	            pst.executeUpdate();
	            con.close();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	    }



}
