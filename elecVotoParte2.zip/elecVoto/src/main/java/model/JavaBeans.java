 package model;

public class JavaBeans {
	 	private String idUsuario;
	    private String usuario;
	    private String email;
	    private String password;
	    private String faculty;
	    private String course;
	    private String ano;
	   
	    
		public String getIdUsuario() {
			return idUsuario;
		}
		public void setIdUsuario(String  idUsuario) {
			this.idUsuario = idUsuario;
		}
		public String getUsuario() {
			return usuario;
		}
		public void setUsuario(String usuario) {
			this.usuario = usuario;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getFaculty() {
			return faculty;
		}
		public void setFaculty(String faculty) {
			this.faculty = faculty;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public String getAno() {
			return ano;
		}
		public void setAno(String ano) {
			this.ano = ano;
		}
	
		

		public JavaBeans(String  idUsuario, String usuario, String email, String password, String faculty, String course,
				String ano) {
			super();
			this.idUsuario = idUsuario;
			this.usuario = usuario;
			this.email = email;
			this.password = password;
			this.faculty = faculty;
			this.course = course;
			this.ano = ano;
		
		}
		
		public JavaBeans() {
			super();
			// TODO Auto-generated constructor stub
		}

}
