package model;

public class JavaBeans2 {
	String idCandidato;
	String idUsuario ;
	String usuario;
	String email;
	String faculty;
     String course;
    String ano;
    String proposta;
    int votos;
    
	public String getIdCandidato() {
		return idCandidato;
	}

	public void setIdCandidato(String idCandidato) {
		this.idCandidato = idCandidato;
	}

	public String getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public String getProposta() {
		return proposta;
	}

	public void setProposta(String proposta) {
		this.proposta = proposta;
	}

	public int getVotos() {
		return votos;
	}

	public void setVotos(int votos) {
		this.votos = votos;
	}

	public JavaBeans2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JavaBeans2(String idCandidato, String idUsuario, String usuario, String email, String faculty, String course,
			String ano, String proposta, int votos) {
		super();
		this.idCandidato = idCandidato;
		this.idUsuario = idUsuario;
		this.usuario = usuario;
		this.email = email;
		this.faculty = faculty;
		this.course = course;
		this.ano = ano;
		this.proposta = proposta;
		this.votos = votos;
	}
}
  
   