package model;

import java.util.Date;

public class JavaBeans3 {

    String idVoto;
    String usuario;
    String idCandidato;
    Date datta;

    public String getIdVoto() {
        return idVoto;
    }

    public void setIdVoto(String idVoto) {
        this.idVoto = idVoto;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getIdCandidato() {
        return idCandidato;
    }

    public void setIdCandidato(String idCandidato) {
        this.idCandidato = idCandidato;
    }

    public Date getDatta() {
        return datta;
    }

    public void setDatta(Date datta) {
        this.datta = datta;
    }

    public JavaBeans3(String idVoto, String usuario, String idCandidato, Date datta) {
        super();
        this.idVoto = idVoto;
        this.usuario = usuario;
        this.idCandidato = idCandidato;
        this.datta = datta;
    }

    public JavaBeans3() {
        super();
    }
}
