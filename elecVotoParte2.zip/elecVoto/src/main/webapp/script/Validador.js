function validar() {
    let usuario = frmCadastro.usuario.value;
    let email = frmCadastro.email.value;
    let password = frmCadastro.password.value;
    let faculty = frmCadastro.faculty.value;
    let course = frmCadastro.course.value;
    let ano = frmCadastro.ano.value;

	    const emailRegex = /^[a-zA-Z0-9._%+-]+@unilurio\.ac\.mz$/;
    if (usuario === "") {
        alert("Preencha o campo usuário");
        frmCadastro.usuario.focus();
        return false;
    } 
   else if (!email.match(emailRegex)) {
        alert("O email deve ter o dominio @unilurio.ac.mz");
        frmCadastro.email.focus();
    } else if (password === "") {
        alert("Preencha o campo password");
        frmCadastro.password.focus();
        return false;
    } else if (faculty === "") {
        alert("Preencha o campo faculty");
        frmCadastro.faculty.focus();
        return false;
    } else if (course === "") {
        alert("Preencha o campo course");
        frmCadastro.course.focus();
        return false;
    } else if (ano === "") {
        alert("Preencha o campo ano");
        frmCadastro.ano.focus();
        return false;
    } else {
        document.forms["frmCadastro"].submit();
    }
}
