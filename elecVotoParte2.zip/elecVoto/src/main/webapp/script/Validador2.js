/**
 * 
 */
function validar() {
    let idUsuario = frmCand.idUsuario.value;
    let usuario = frmCand.usuario.value;
    let email = frmCand.email.value;
    let faculty = frmCand.faculty.value;
    let course = frmCand.course.value;
    let ano = frmCand.ano.value;
    let proposta = frmCand.proposta.value;

    if (idUsuario === "") {
        alert("Preencha o campo idUsuário");
        frmCand.idUsuario.focus();
        return false;
    } else if (usuario === "") {
        alert("Preencha o campo usuário");
        frmCand.usuario.focus();
        return false;
    } else if (email === "") {
        alert("Preencha o campo email");
        frmCand.email.focus();
        return false;
    } else if (!isValidEmail(email)) {
        alert("O email deve ter o domínio @unilurio.ac.mz");
        frmCand.email.focus();
        return false;
    } else if (faculty === "") {
        alert("Preencha o campo faculty");
        frmCand.faculty.focus();
        return false;
    } else if (course === "") {
        alert("Preencha o campo course");
        frmCand.course.focus();
        return false;
    } else if (ano === "") {
        alert("Preencha o campo ano");
        frmCand.ano.focus();
        return false;
    }else if (proposta === "") {
        alert("Preencha o campo ano");
        frmCand.ano.focus();
        return false;
    }  else {
        document.forms["frmCand"].submit();
    }
}

// Função para verificar se o email possui o domínio correto
function isValidEmail(email) {
    return /@unilurio\.ac\.mz$/.test(email);
}

