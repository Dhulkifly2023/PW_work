/**
 * confrimacao de exclusão
 */

 function confirmar(idUsuario)
 {
	 let resposta = confirm("Confirma a exclusao deste usuario ?")
	 
	 if(resposta === true)
	 {
		
	 window.location.href="delete?idUsuario=" + idUsuario
	 }
 }
 
 
  function confirmar2(idUsuario)
 {
	 let resposta = confirm("Confirma a exclusao deste usuario ?")
	 
	 if(resposta === true)
	 {
		
	 window.location.href="delete2?idUsuario=" + idUsuario
	 }
 }
 