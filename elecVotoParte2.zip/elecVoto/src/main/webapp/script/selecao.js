/**
 * 
 */
    // Referencie os elementos select
    const facultySelect = document.getElementById("facultySelect");
    const courseSelect = document.getElementById("courseSelect");

    // Defina os cursos disponíveis para cada faculdade
    const courses = {
        Ciencias_Naturais: ["Biologia", "Química", "Recursos Naturais"],
        engenharia: ["Engenharia Informática", "Engenharia Geológica", "Engenharia Mecânica", "Engenharia Civil"],
    };

    // Adicione um ouvinte de evento de alteração à seleção da faculdade
    facultySelect.addEventListener("change", function () {
        const selectedFaculty = facultySelect.value;
        const availableCourses = courses[selectedFaculty] || [];

        // Limpe a seleção atual no menu de cursos
        courseSelect.innerHTML = "";

        // Crie novas opções com base na faculdade selecionada
        const defaultOption = document.createElement("option");
        defaultOption.value = "";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        defaultOption.textContent = "Escolha o curso";
        courseSelect.appendChild(defaultOption);

        availableCourses.forEach(function (course) {
            const option = document.createElement("option");
            option.value = course;
            option.textContent = course;
            courseSelect.appendChild(option);
        });
    });
